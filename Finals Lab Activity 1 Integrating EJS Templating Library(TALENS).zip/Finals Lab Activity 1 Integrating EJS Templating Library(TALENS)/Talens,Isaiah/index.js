const express = require('express');
const app = express();

app.set('view engine', 'ejs');

app.use(express.static('public'));

app.get('/', (req, res) => {
    res.render('index', {
        full_name: 'Isaiah Genre M. Talens',
        address: 'Fiesta Communities Tabun',
        phone_num: '0919220323222',
        email_address: 'imtalens.cscsoc@gmail.com',
        objective: 'To be successful ',
        imageFile: '12.jpg',
        elementary: 'Marisol Bliss',
        juniorHigh: 'CMRICTHS',
        seniorHigh: 'Holy Angel University | Humanities and Social Sciences',
        college: 'Holy Angel University',
        course: 'Bachelor of Science in Information Technology',
        specialization: 'Web Development',
        trainings: ['NONE'],
        seminars: ['NONE'],
        technologies: ['MySQL', 'HTML5', 'CSS'],
        languages: ['Java', 'Python', 'JavaScript', 'PHP'],

    });
});

app.listen(3000, () => {
    console.log('Server started.');
});
